import {callGetList} from '../api/axiosClient';
import {EmployeeMasterListResponse} from '../api/interfaces/EmployeeTypes';

/**
 * Service for employee-related API operations.
 *
 * Authentication: the `axiosClient` interceptor automatically attaches
 * `SecurityToken: <token>` to every outgoing request. The token is also
 * included in the `filters` payload via `callGetList` for backward
 * compatibility with the original Synergy web API contract.
 */
export const EmployeeService = {
  /**
   * Fetches the complete employee master list from the backend.
   * Uses the mobile equivalent of the web API's `callGetList` method.
   */
  getEmployeeMasterList: async (): Promise<EmployeeMasterListResponse> => {
    const response = await callGetList<EmployeeMasterListResponse['Data']>(
      'GetEmployeeMasterList',
    );

    return response as EmployeeMasterListResponse;
  },
};
