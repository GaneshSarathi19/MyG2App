import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  TouchableWithoutFeedback,
  Keyboard,
} from 'react-native';
import { Colors, Fonts } from '../../theme';
import { useAuth } from '../../context/AuthContext';
import ErrorView from '../../components/ErrorView';
import LogoContainer from '../../components/LogoContainer';
import AppScreen from '../../components/layout/AppScreen';

const EMAIL_REGEX = /^[\w-.]+@[\w-]+\.[A-Za-z]{2,}$/;

/* ─── Colors ───────────────────────────────────────────────────────── */

const LoginScreen = () => {
  const { login } = useAuth();

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const [touched, setTouched] = useState({
    username: false,
    password: false,
  });

  const [showPassword, setShowPassword] = useState(false);

  const [errors, setErrors] = useState<{
    username?: string;
    password?: string;
  }>({});

  const [loading, setLoading] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);

  const validate = () => {
    const newErrors: {
      username?: string;
      password?: string;
    } = {};

    if (!username.trim()) {
      newErrors.username = 'Username is required';
    } else if (username.includes('@') && !EMAIL_REGEX.test(username)) {
      newErrors.username = 'Enter a valid email address';
    }

    if (!password.trim()) {
      newErrors.password = 'Password is required';
    }

    return newErrors;
  };

  /**
   * Triggers the backend (or mock) login validation.
   */
  const handleLogin = async () => {
    setLoading(true);
    setLoginError(null);

    const validation = validate();

    setTouched({
      username: true,
      password: true,
    });

    setErrors(validation);

    if (validation.username || validation.password) {
      setLoading(false);
      return;
    }

    try {
      const result = await login(username, password);

      if (!result.success) {
        setLoginError(result.message);
      } else {
        setErrors({});
        setTouched({
          username: false,
          password: false,
        });
      }
    } catch (error) {
      const message =
        error instanceof Error
          ? error.message
          : 'Login failed - please try again.';
      setLoginError(message);
    } finally {
      setLoading(false);
    }
  };

  const clearLoginError = () => {
    setLoginError(null);
  };

  return (
    <AppScreen>
    <TouchableWithoutFeedback
      accessible={false}
      onPress={Keyboard.dismiss}
    >
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContainer}
          keyboardShouldPersistTaps="handled"
        >
          {/* Top decorative banner */}
          <View style={styles.banner}>
            <View style={styles.bannerAccent} />
          </View>

          <View style={styles.card}>
            <LogoContainer
              variant="full"
              source={require('../../resources/g2logo-small.png')}
            />

            {loginError && (
              <View style={styles.errorWrap}>
                <ErrorView message={loginError} onRetry={clearLoginError} />
              </View>
            )}

            <TextInput
              style={[
                styles.input,
                touched.username && errors.username && styles.inputError,
              ]}
              placeholder="Username"
              placeholderTextColor="#9CA3AF"
              value={username}
              onChangeText={setUsername}
              autoCapitalize="none"
              autoCorrect={false}
              returnKeyType="done"
              onFocus={() => {
                setTouched((prev) => ({
                  ...prev,
                  username: true,
                }));
              }}
            />

            {touched.username && errors.username ? (
              <Text style={styles.errorText}>{errors.username}</Text>
            ) : null}

            <View
              style={[
                styles.passwordContainer,
                touched.password && errors.password && styles.inputError,
              ]}
            >
              <TextInput
                style={styles.passwordInput}
                placeholder="Password"
                placeholderTextColor="#9CA3AF"
                value={password}
                onChangeText={setPassword}
                secureTextEntry={!showPassword}
                autoCapitalize="none"
                returnKeyType="done"
                onSubmitEditing={handleLogin}
                onFocus={() => {
                  setTouched((prev) => ({
                    ...prev,
                    password: true,
                  }));
                }}
              />

              <TouchableOpacity
                onPress={() => setShowPassword(!showPassword)}
              >
                <Text style={styles.toggleText}>
                  {showPassword ? 'Hide' : 'Show'}
                </Text>
              </TouchableOpacity>
            </View>

            {touched.password && errors.password ? (
              <Text style={styles.errorText}>{errors.password}</Text>
            ) : null}

            <TouchableOpacity
              style={[styles.loginButton, loading && styles.loginButtonDisabled]}
              onPress={handleLogin}
              disabled={loading}
            >
              {loading ? (
                <Text style={styles.loginButtonText}>Signing in...</Text>
              ) : (
                <Text style={styles.loginButtonText}>Sign In</Text>
              )}
            </TouchableOpacity>

            <Text style={styles.demoText}>
              Demo Credentials:{'\n'}Username: admin{'\n'}Password: 1234
            </Text>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </TouchableWithoutFeedback>
  </AppScreen>
  );
};

const styles = StyleSheet.create({
  flex: {
    flex: 1,
    backgroundColor: Colors.subtle,
  },

  scrollContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    paddingVertical: 24,
  },

  banner: {
    height: 6,
    backgroundColor: Colors.primary,
    marginHorizontal: 20,
    borderTopLeftRadius: 4,
    borderTopRightRadius: 4,
    overflow: 'hidden',
    flexDirection: 'row',
  },
  bannerAccent: {
    width: '33%',
    height: '100%',
    backgroundColor: Colors.accent,
  },

  card: {
    marginHorizontal: 20,
    padding: 24,
    borderRadius: 16,
    backgroundColor: Colors.background,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 12,
    elevation: 5,
  },

  input: {
    height: 52,
    borderWidth: 1,
    borderColor: Colors.inputBorder,
    borderRadius: 10,
    paddingHorizontal: 14,
    backgroundColor: Colors.background,
    fontSize: 15,
    color: Colors.dark,
    marginBottom: 6,
  },
  inputError: {
    borderColor: Colors.danger,
  },

  passwordContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    height: 52,
    borderWidth: 1,
    borderColor: Colors.inputBorder,
    borderRadius: 10,
    backgroundColor: Colors.background,
    paddingHorizontal: 14,
    marginTop: 8,
  },

  passwordInput: {
    flex: 1,
    fontSize: 15,
    color: Colors.dark,
  },

  toggleText: {
    color: Colors.primary,
    fontWeight: '700',
    fontSize: 13,
  },

  errorText: {
    color: Colors.danger,
    marginTop: 2,
    marginBottom: 8,
    fontSize: 12,
    fontWeight: '500',
  },

  errorWrap: {
    marginBottom: 16,
  },

  loginButton: {
    height: 52,
    borderRadius: 10,
    backgroundColor: Colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 16,
  },
  loginButtonDisabled: {
    opacity: 0.7,
  },
  loginButtonText: {
    color: Colors.background,
    fontSize: 15,
    fontWeight: '700',
  },

  demoText: {
    marginTop: 20,
    textAlign: 'center',
    color: Colors.textSecondary,
    fontSize: 12,
    lineHeight: 18,
  },
});

export default LoginScreen;
